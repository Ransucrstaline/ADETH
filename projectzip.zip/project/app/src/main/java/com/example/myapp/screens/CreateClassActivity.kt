package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class CreateClassActivity : AppCompatActivity() {

    private lateinit var btnAdd: ImageView
    private lateinit var btnMenu: ImageView
    private lateinit var imgFilter: ImageView
    private lateinit var imgSearch: ImageView
    private lateinit var btnBack: ImageView

    private lateinit var navHome: LinearLayout
    private lateinit var navClasses: LinearLayout
    private lateinit var navNotification: LinearLayout
    private lateinit var navProfile: LinearLayout
    private lateinit var navMore: LinearLayout

    private lateinit var etSearch: EditText
    private lateinit var etClassName: EditText
    private lateinit var etSection: EditText
    private lateinit var etSchedule: EditText
    private lateinit var etRoomNumber: EditText

    private lateinit var dropAcademicLevel: LinearLayout
    private lateinit var tvAcademicLevel: TextView

    private lateinit var btnCancel: Button
    private lateinit var btnCreate: Button

    private val academicLevels = arrayOf(
        "Grade 7", "Grade 8", "Grade 9", "Grade 10",
        "Grade 11", "Grade 12",
        "1st Year College", "2nd Year College",
        "3rd Year College", "4th Year College"
    )

    private var currentAcademicIndex = -1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_class)

        initViews()
        setupClicks()
    }

    private fun initViews() {
        btnAdd = findViewById(R.id.btnAdd)
        btnMenu = findViewById(R.id.btnMenu)
        imgFilter = findViewById(R.id.imgFilter)
        imgSearch = findViewById(R.id.imgSearch)
        btnBack = findViewById(R.id.btnBack)

        navHome = findViewById(R.id.navHome)
        navClasses = findViewById(R.id.navClasses)
        navNotification = findViewById(R.id.navNotification)
        navProfile = findViewById(R.id.navProfile)
        navMore = findViewById(R.id.navMore)

        etSearch = findViewById(R.id.etSearch)
        etClassName = findViewById(R.id.etClassName)
        etSection = findViewById(R.id.etSection)
        etSchedule = findViewById(R.id.etSchedule)
        etRoomNumber = findViewById(R.id.etRoomNumber)

        dropAcademicLevel = findViewById(R.id.dropAcademicLevel)
        tvAcademicLevel = findViewById(R.id.tvAcademicLevel)

        btnCancel = findViewById(R.id.btnCancel)
        btnCreate = findViewById(R.id.btnCreate)
    }

    private fun setupClicks() {

        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class to search", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching for: $query", Toast.LENGTH_SHORT).show()
            }
        }

        dropAcademicLevel.setOnClickListener {
            cycleAcademicLevel()
        }

        btnCancel.setOnClickListener {
            clearFields()
            Toast.makeText(this, "Form cleared", Toast.LENGTH_SHORT).show()
        }

        btnCreate.setOnClickListener {
            createClass()
        }

        btnBack.setOnClickListener {
            finish()
        }

        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {
        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navClasses.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
            finish()
        }

        navMore.setOnClickListener {
            startActivity(Intent(this, MoreActivity::class.java))
            finish()
        }
    }

    private fun cycleAcademicLevel() {
        currentAcademicIndex++
        if (currentAcademicIndex >= academicLevels.size) {
            currentAcademicIndex = 0
        }
        tvAcademicLevel.text = academicLevels[currentAcademicIndex]
    }

    private fun clearFields() {
        etClassName.text.clear()
        etSection.text.clear()
        etSchedule.text.clear()
        etRoomNumber.text.clear()
        tvAcademicLevel.text = getString(R.string.select_academic_level)
        currentAcademicIndex = -1
    }

    private fun createClass() {
        val className = etClassName.text.toString().trim()

        if (className.isEmpty()) {
            Toast.makeText(this, "Enter class name", Toast.LENGTH_SHORT).show()
            return
        }

        Toast.makeText(this, "Class created: $className", Toast.LENGTH_SHORT).show()
        startActivity(Intent(this, MyClassesActivity::class.java))
        finish()
    }
}