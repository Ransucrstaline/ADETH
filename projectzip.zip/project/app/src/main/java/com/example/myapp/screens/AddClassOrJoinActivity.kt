package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class AddClassOrJoinActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_class_or_join)

        // ===== TOP BUTTONS =====
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnClose = findViewById<ImageView>(R.id.btnClose)

        // ===== MAIN BUTTONS =====
        val btnCreateClass = findViewById<LinearLayout>(R.id.btnCreateClass)
        val btnJoinClass = findViewById<LinearLayout>(R.id.btnJoinClass)

        // ===== NAVIGATION =====
        val navHome = findViewById<LinearLayout>(R.id.navHome)
        val navClasses = findViewById<LinearLayout>(R.id.navClasses)
        val navNotification = findViewById<LinearLayout>(R.id.navNotification)

        // =========================
        // CREATE CLASS
        // =========================
        btnCreateClass.setOnClickListener {
            startActivity(Intent(this, CreateClassActivity::class.java))
        }

        // =========================
        // JOIN CLASS
        // =========================
        btnJoinClass.setOnClickListener {
            startActivity(Intent(this, JoinClass::class.java))
        }

        // =========================
        // CLOSE
        // =========================
        btnClose.setOnClickListener {
            finish()
        }

        // =========================
        // MENU
        // =========================
        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        // =========================
        // EXTRA
        // =========================
        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        // =========================
        // BOTTOM NAV
        // =========================
        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navClasses.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }
    }
}