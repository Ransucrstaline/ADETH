package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Notification : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)
        val etSearch = findViewById<EditText>(R.id.etSearch)

        val layoutMarkAllRead = findViewById<LinearLayout>(R.id.layoutMarkAllRead)
        val tvMarkAllRead = findViewById<TextView>(R.id.tvMarkAllRead)

        // 🔝 TOP ACTIONS
        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        layoutMarkAllRead.setOnClickListener {
            Toast.makeText(this, "All notifications marked as read", Toast.LENGTH_SHORT).show()
        }

        tvMarkAllRead.setOnClickListener {
            Toast.makeText(this, "All notifications marked as read", Toast.LENGTH_SHORT).show()
        }

        etSearch.setOnEditorActionListener { _, _, _ ->
            Toast.makeText(this, "Searching: ${etSearch.text}", Toast.LENGTH_SHORT).show()
            true
        }

        // ✅ CALL NAVIGATION
        setupBottomNavigation()
    }

    // ✅ FINAL VERSION (WITH CHECKS)
    private fun setupBottomNavigation() {

        findViewById<LinearLayout>(R.id.navHome).setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navClasses).setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navNotification).setOnClickListener {
            // already here
        }

        findViewById<LinearLayout>(R.id.navProfile).setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navMore).setOnClickListener {
            startActivity(Intent(this, MoreActivity::class.java))
            finish()
        }
    }
}