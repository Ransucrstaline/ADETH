package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class UploadMaterialActivity : AppCompatActivity() {

    private lateinit var imgLogo: ImageView
    private lateinit var btnAdd: ImageView
    private lateinit var btnMenu: ImageView

    private lateinit var etSearch: EditText
    private lateinit var imgSearch: ImageView
    private lateinit var imgFilter: ImageView

    private lateinit var etMaterialTitle: EditText
    private lateinit var etMaterialDescription: EditText
    private lateinit var uploadDropZone: LinearLayout

    private lateinit var btnCancel: Button
    private lateinit var btnUpload: Button
    private lateinit var btnBack: ImageView   // ✅ changed from btnClose

    private lateinit var navHome: LinearLayout
    private lateinit var navClasses: LinearLayout
    private lateinit var navNotification: LinearLayout
    private lateinit var navProfile: LinearLayout
    private lateinit var navMore: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_upload_material)

        initViews()
        setupClicks()
    }

    private fun initViews() {
        imgLogo = findViewById(R.id.imgLogo)
        btnAdd = findViewById(R.id.btnAdd)
        btnMenu = findViewById(R.id.btnMenu)

        etSearch = findViewById(R.id.etSearch)
        imgSearch = findViewById(R.id.imgSearch)
        imgFilter = findViewById(R.id.imgFilter)

        etMaterialTitle = findViewById(R.id.etMaterialTitle)
        etMaterialDescription = findViewById(R.id.etMaterialDescription)
        uploadDropZone = findViewById(R.id.uploadDropZone)

        btnCancel = findViewById(R.id.btnCancel)
        btnUpload = findViewById(R.id.btnUpload)
        btnBack = findViewById(R.id.btnBack) // ✅ FIXED

        navHome = findViewById(R.id.navHome)
        navClasses = findViewById(R.id.navClasses)
        navNotification = findViewById(R.id.navNotification)
        navProfile = findViewById(R.id.navProfile)
        navMore = findViewById(R.id.navMore)
    }

    private fun setupClicks() {

        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class to search", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching for: $query", Toast.LENGTH_SHORT).show()
            }
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        uploadDropZone.setOnClickListener {
            Toast.makeText(this, "Choose a file to upload", Toast.LENGTH_SHORT).show()
        }

        btnCancel.setOnClickListener {
            clearFields()
            Toast.makeText(this, "Upload cancelled", Toast.LENGTH_SHORT).show()
        }

        // ✅ SIMPLE UPLOAD LOGIC APPLIED
        btnUpload.setOnClickListener {
            Toast.makeText(this, "Material uploaded", Toast.LENGTH_SHORT).show()
        }

        // ✅ SIMPLE BACK BUTTON APPLIED
        btnBack.setOnClickListener {
            finish()
        }

        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navClasses.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
            finish()
        }

        navMore.setOnClickListener {
            startActivity(Intent(this, MoreActivity::class.java))
            finish()
        }
    }

    private fun clearFields() {
        etMaterialTitle.text.clear()
        etMaterialDescription.text.clear()
    }
}