package com.example.myapp.screens

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class EditAnnouncementActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_announcement)

        val btnAdd = findViewById<ImageButton>(R.id.btnAdd)
        val btnMenu = findViewById<ImageButton>(R.id.btnMenu)
        val imgFilter = findViewById<ImageView>(R.id.imgFilter)
        val btnClose = findViewById<ImageView>(R.id.btnClose)

        val tvImportant = findViewById<TextView>(R.id.tvImportant)
        val tvUpdate = findViewById<TextView>(R.id.tvUpdate)
        val tvDeadline = findViewById<TextView>(R.id.tvDeadline)

        val etTitle = findViewById<EditText>(R.id.etTitle)
        val etDescription = findViewById<EditText>(R.id.etDescription)

        val btnUndo = findViewById<ImageView>(R.id.btnUndo)
        val btnRedo = findViewById<ImageView>(R.id.btnRedo)
        val btnCancel = findViewById<Button>(R.id.btnCancel)
        val btnApply = findViewById<Button>(R.id.btnApply)

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnClose.setOnClickListener {
            finish()
        }

        tvImportant.setOnClickListener {
            Toast.makeText(this, "Important selected", Toast.LENGTH_SHORT).show()
        }

        tvUpdate.setOnClickListener {
            Toast.makeText(this, "Update selected", Toast.LENGTH_SHORT).show()
        }

        tvDeadline.setOnClickListener {
            Toast.makeText(this, "Deadline selected", Toast.LENGTH_SHORT).show()
        }

        btnUndo.setOnClickListener {
            Toast.makeText(this, "Undo clicked", Toast.LENGTH_SHORT).show()
        }

        btnRedo.setOnClickListener {
            Toast.makeText(this, "Redo clicked", Toast.LENGTH_SHORT).show()
        }

        btnCancel.setOnClickListener {
            finish()
        }

        btnApply.setOnClickListener {
            val title = etTitle.text.toString().trim()
            val description = etDescription.text.toString().trim()

            when {
                title.isEmpty() -> etTitle.error = "Please enter a title"
                description.isEmpty() -> etDescription.error = "Please enter a description"
                else -> Toast.makeText(this, "Announcement updated", Toast.LENGTH_SHORT).show()
            }
        }
    }
}