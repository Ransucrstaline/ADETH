package com.example.myapp.screens

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class StudentRecordsQuiz : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_records_quiz)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)
        val btnCalendar = findViewById<ImageView>(R.id.btnCalendar)
        val etSearch = findViewById<EditText>(R.id.etSearch)
        val tableBody = findViewById<LinearLayout>(R.id.tableBody)

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        etSearch.setOnEditorActionListener { _, _, _ ->
            Toast.makeText(this, "Searching: ${etSearch.text}", Toast.LENGTH_SHORT).show()
            true
        }

        tableBody.setOnClickListener {
            Toast.makeText(this, "Quiz table", Toast.LENGTH_SHORT).show()
        }
    }
}