package com.example.myapp.screens

import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Missing : AppCompatActivity() {

    private lateinit var btnAdd: ImageView
    private lateinit var btnMenu: ImageView
    private lateinit var btnFilter: ImageView
    private lateinit var btnCalendar: ImageView

    private lateinit var etSearch: EditText

    private lateinit var tabMaterials: TextView
    private lateinit var tabTodo: TextView
    private lateinit var tabAnnouncement: TextView

    private lateinit var dropdownMissing: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_classes)

        initViews()
        setupClicks()
        setupSearch()
        setSelectedTab("todo")
    }

    private fun initViews() {
        btnAdd = findViewById(R.id.btnAdd)
        btnMenu = findViewById(R.id.btnMenu)
        btnFilter = findViewById(R.id.btnFilter)
        btnCalendar = findViewById(R.id.btnCalendar)

        etSearch = findViewById(R.id.etSearch)

        tabMaterials = findViewById(R.id.tabMaterials)
        tabTodo = findViewById(R.id.tabTodo)
        tabAnnouncement = findViewById(R.id.tabAnnouncement)

        dropdownMissing = findViewById(R.id.dropdownMissing)
    }

    private fun setupClicks() {
        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        dropdownMissing.setOnClickListener {
            Toast.makeText(this, "Missing dropdown clicked", Toast.LENGTH_SHORT).show()
        }

        tabMaterials.setOnClickListener {
            setSelectedTab("materials")
        }

        tabTodo.setOnClickListener {
            setSelectedTab("todo")
        }

        tabAnnouncement.setOnClickListener {
            setSelectedTab("announcement")
        }
    }

    private fun setupSearch() {
        etSearch.setOnEditorActionListener { _, _, _ ->
            val text = etSearch.text.toString()
            Toast.makeText(this, "Searching: $text", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun setSelectedTab(selected: String) {
        tabMaterials.background = null
        tabTodo.background = null
        tabAnnouncement.background = null

        when (selected) {
            "materials" -> tabMaterials.setBackgroundResource(R.drawable.bg_tab_selected)
            "todo" -> tabTodo.setBackgroundResource(R.drawable.bg_tab_selected)
            "announcement" -> tabAnnouncement.setBackgroundResource(R.drawable.bg_tab_selected)
        }
    }
}