package com.example.myapp.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class ClassDetailsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_class_details)

        // ===== HEADER BUTTONS =====
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)

        // ===== TOP CONTROLS =====
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val btnCalendar = findViewById<LinearLayout>(R.id.btnCalendar)

        // ===== SUBJECT / CLASS INFO =====
        val tvSubjectName = findViewById<TextView>(R.id.tvSubjectName)
        val tvSectionName = findViewById<TextView>(R.id.tvSectionName)
        val tvClassTitle = findViewById<TextView>(R.id.tvClassTitle)

        // ===== ENROLLMENT =====
        val tvEnrollmentCode = findViewById<TextView>(R.id.tvEnrollmentCode)
        val btnCopyCode = findViewById<LinearLayout>(R.id.btnCopyCode)

        // ===== LESSONS =====
        val lesson1 = findViewById<LinearLayout>(R.id.lesson1Card)
        val lesson2 = findViewById<LinearLayout>(R.id.lesson2Card)

        // ===== ACTION BUTTONS =====
        val btnAnnouncements = findViewById<LinearLayout>(R.id.btnAnnouncements)
        val btnAttendance = findViewById<LinearLayout>(R.id.btnAttendance)
        val btnDeadline = findViewById<LinearLayout>(R.id.btnDeadline)
        val btnQuiz = findViewById<LinearLayout>(R.id.btnQuiz)
        val btnStudentRecords = findViewById<LinearLayout>(R.id.btnStudentRecords)
        val btnUploadMaterial = findViewById<LinearLayout>(R.id.btnUploadMaterial)
        val btnCreateQuiz = findViewById<LinearLayout>(R.id.btnCreateQuiz)

        // ===== NAVIGATION =====
        val navHome = findViewById<LinearLayout>(R.id.navHome)
        val navClasses = findViewById<LinearLayout>(R.id.navClasses)
        val navNotification = findViewById<LinearLayout>(R.id.navNotification)
        val navProfile = findViewById<LinearLayout>(R.id.navProfile)
        val navMore = findViewById<LinearLayout>(R.id.navMore)

        // ===== GET DATA =====
        val className = intent.getStringExtra("class_name")
        val subjectName = intent.getStringExtra("subject_name")

        val displayTitle = className ?: subjectName ?: "Class Details"

        tvSubjectName.text = displayTitle
        tvClassTitle.text = displayTitle

        // ===== BUTTON ACTIONS =====
        btnAdd.setOnClickListener {
            startActivity(Intent(this, AddClassOrJoinActivity::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        btnBack.setOnClickListener {
            finish()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        // ===== COPY ENROLLMENT CODE =====
        btnCopyCode.setOnClickListener {
            val code = tvEnrollmentCode.text.toString()

            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Enrollment Code", code)
            clipboard.setPrimaryClip(clip)

            Toast.makeText(this, "Copied: $code", Toast.LENGTH_SHORT).show()
        }

        // ===== LESSON CLICK =====
        lesson1.setOnClickListener {
            Toast.makeText(this, "Open Lesson 1", Toast.LENGTH_SHORT).show()
        }

        lesson2.setOnClickListener {
            Toast.makeText(this, "Open Lesson 2", Toast.LENGTH_SHORT).show()
        }

        // ===== ACTION BUTTONS =====
        btnAnnouncements.setOnClickListener {
            startActivity(Intent(this, Announcements::class.java))
        }

        btnAttendance.setOnClickListener {
            startActivity(Intent(this, AttendanceActivity::class.java))
        }

        btnDeadline.setOnClickListener {
            startActivity(Intent(this, Deadline::class.java))
        }

        btnQuiz.setOnClickListener {
            startActivity(Intent(this, Quiz::class.java))
        }

        btnStudentRecords.setOnClickListener {
            startActivity(Intent(this, StudentRecords::class.java))
        }

        btnUploadMaterial.setOnClickListener {
            startActivity(Intent(this, UploadMaterialActivity::class.java))
        }

        btnCreateQuiz.setOnClickListener {
            startActivity(Intent(this, CreateQuiz::class.java))
        }

        // ===== BOTTOM NAV =====
        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navClasses.setOnClickListener {
            Toast.makeText(this, "Already in Classes", Toast.LENGTH_SHORT).show()
        }

        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
            finish()
        }

        navMore.setOnClickListener {
            startActivity(Intent(this, MoreActivity::class.java))
            finish()
        }
    }
}