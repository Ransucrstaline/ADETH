package com.example.myapp.screens

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class QuizTruFalse : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quiz_true_false)

        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnBackQuestion = findViewById<Button>(R.id.btnBackQuestion)
        val btnSubmit = findViewById<Button>(R.id.btnSubmit)

        val rbTrue1 = findViewById<RadioButton>(R.id.rbTrue1)
        val rbFalse1 = findViewById<RadioButton>(R.id.rbFalse1)
        val rbTrue2 = findViewById<RadioButton>(R.id.rbTrue2)
        val rbFalse2 = findViewById<RadioButton>(R.id.rbFalse2)

        btnBack.setOnClickListener { finish() }

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnBackQuestion.setOnClickListener {
            Toast.makeText(this, "Back clicked", Toast.LENGTH_SHORT).show()
        }

        btnSubmit.setOnClickListener {
            val message = when {
                rbTrue1.isChecked || rbFalse1.isChecked || rbTrue2.isChecked || rbFalse2.isChecked ->
                    "Submitted"
                else -> "Please select an answer"
            }
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }
}