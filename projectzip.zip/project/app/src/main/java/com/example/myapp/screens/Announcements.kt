package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Announcements : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_announcements)

        // ===== HEADER BUTTONS =====
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnBack = findViewById<ImageView>(R.id.btnBack)

        // ===== SEARCH + FILTER =====
        val etSearch = findViewById<EditText>(R.id.etSearch)
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)

        // ===== CALENDAR FLOAT BUTTON =====
        val btnCalendar = findViewById<ImageView>(R.id.btnCalendar)

        // ===== CATEGORY CHIPS =====
        val chipAll = findViewById<TextView>(R.id.chipAll)
        val chipImportant = findViewById<TextView>(R.id.chipImportant)
        val chipUpdate = findViewById<TextView>(R.id.chipUpdate)
        val chipDeadline = findViewById<TextView>(R.id.chipDeadline)

        // ===== ANNOUNCEMENT ACTIONS =====
        val btnAddAnnouncement = findViewById<LinearLayout>(R.id.btnAddAnnouncement)

        // ===== CLICK EVENTS =====
        btnBack.setOnClickListener {
            finish()
        }

        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        chipAll.setOnClickListener {
            Toast.makeText(this, "All selected", Toast.LENGTH_SHORT).show()
        }

        chipImportant.setOnClickListener {
            Toast.makeText(this, "Important selected", Toast.LENGTH_SHORT).show()
        }

        chipUpdate.setOnClickListener {
            Toast.makeText(this, "Update selected", Toast.LENGTH_SHORT).show()
        }

        chipDeadline.setOnClickListener {
            Toast.makeText(this, "Deadline selected", Toast.LENGTH_SHORT).show()
        }

        btnAddAnnouncement.setOnClickListener {
            startActivity(Intent(this, AnnouncementActivity::class.java))
        }


        // ===== SEARCH ACTION =====
        etSearch.setOnEditorActionListener { _, _, _ ->
            val text = etSearch.text.toString()
            Toast.makeText(this, "Searching: $text", Toast.LENGTH_SHORT).show()
            true
        }
    }
}