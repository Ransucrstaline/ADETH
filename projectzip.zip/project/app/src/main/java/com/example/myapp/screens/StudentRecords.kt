package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class StudentRecords : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var tableBody: LinearLayout

    private val studentRecords = listOf(
        StudentInfo(
            name = "Hannah Isabelle",
            section = "BSCS 3A",
            attendanceList = listOf(
                AttendanceInfo("Present - 28", 30, listOf("April 10, 2026", "April 12, 2026")),
                AttendanceInfo("Late - 2", 30, listOf("April 11, 2026", "April 18, 2026")),
                AttendanceInfo("Absent - 1", 30, listOf("April 20, 2026"))
            )
        ),
        StudentInfo(
            name = "John Cruz",
            section = "BSCS 3B",
            attendanceList = listOf(
                AttendanceInfo("Present - 25", 27, listOf("April 10, 2026")),
                AttendanceInfo("Absent - 2", 27, listOf("April 14, 2026"))
            )
        ),
        StudentInfo(
            name = "Maria Santos",
            section = "BSIT 2A",
            attendanceList = listOf(
                AttendanceInfo("Present - 32", 35, listOf("April 09, 2026")),
                AttendanceInfo("Late - 1", 35, listOf("April 17, 2026"))
            )
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_records)

        // ===== HEADER BUTTONS =====
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)
        val btnCalendar = findViewById<ImageView>(R.id.btnCalendar)

        // ===== INPUTS =====
        etSearch = findViewById(R.id.etSearch)
        tableBody = findViewById(R.id.tableBody)

        // ===== BUTTON ACTIONS =====
        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        // ===== INITIAL DATA LOAD =====
        renderStudentRows(studentRecords)

        // ===== SEARCH =====
        etSearch.setOnEditorActionListener { _, _, _ ->
            val query = etSearch.text.toString().trim().lowercase()

            val filtered = studentRecords.filter {
                it.name.lowercase().contains(query) ||
                        it.section.lowercase().contains(query)
            }

            renderStudentRows(filtered)

            Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun renderStudentRows(list: List<StudentInfo>) {
        tableBody.removeAllViews()

        if (list.isEmpty()) {
            val emptyText = TextView(this).apply {
                text = "No student records found"
                textSize = 15f
                setPadding(32, 32, 32, 32)
            }
            tableBody.addView(emptyText)
            return
        }

        list.forEachIndexed { index, item ->

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(24, 24, 24, 24)
            }

            val nameText = TextView(this).apply {
                text = item.name
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val sectionText = TextView(this).apply {
                text = item.section
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            row.addView(nameText)
            row.addView(sectionText)

            // 👉 CLICK GOES TO ATTENDANCE
            row.setOnClickListener {
                val intent = Intent(this, StudentRecordsAttendance::class.java)
                intent.putExtra("student_name", item.name)
                intent.putExtra("student_section", item.section)
                startActivity(intent)
            }

            tableBody.addView(row)

            // divider
            if (index != list.lastIndex) {
                val divider = android.view.View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT, 1
                    )
                    setBackgroundColor(android.graphics.Color.parseColor("#D9D9D9"))
                }
                tableBody.addView(divider)
            }
        }
    }
}