package com.example.myapp.screens

data class StudentInfo(
    val name: String,
    val section: String,
    val attendanceList: List<AttendanceInfo>
)

data class AttendanceInfo(
    val attendanceLabel: String,
    val totalStudents: Int,
    val dateList: List<String>
)