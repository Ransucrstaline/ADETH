package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class MyClassesActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_classes)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)

        val etSearch = findViewById<EditText>(R.id.etSearch)
        val imgSearch = findViewById<ImageView>(R.id.imgSearch)
        val imgFilter = findViewById<ImageView>(R.id.imgFilter)

        val imgFilipinoCard = findViewById<ImageView>(R.id.imgFilipinoCard)
        val imgMathCard = findViewById<ImageView>(R.id.imgMathCard)
        val imgPeCard = findViewById<ImageView>(R.id.imgPeCard)
        val imgEnglishCard = findViewById<ImageView>(R.id.imgEnglishCard)

        val tvFilipino = findViewById<TextView>(R.id.tvFilipino)
        val tvMath = findViewById<TextView>(R.id.tvMath)
        val tvPe = findViewById<TextView>(R.id.tvPe)
        val tvEnglish = findViewById<TextView>(R.id.tvEnglish)

        val classCard1 = findViewById<LinearLayout>(R.id.classCard1)
        val classCard2 = findViewById<LinearLayout>(R.id.classCard2)
        val btnAddClass = findViewById<LinearLayout>(R.id.btnAddClass)

        setupTopButtons(btnAdd, btnMenu, btnAddClass)
        setupSearch(etSearch, imgSearch, imgFilter)
        setupClassClicks(
            imgFilipinoCard, imgMathCard, imgPeCard, imgEnglishCard,
            tvFilipino, tvMath, tvPe, tvEnglish,
            classCard1, classCard2
        )
        setupBottomNavigation()
    }

    private fun setupTopButtons(
        btnAdd: ImageView,
        btnMenu: ImageView,
        btnAddClass: LinearLayout
    ) {
        btnAdd.setOnClickListener {
            startActivity(Intent(this, AddClassOrJoinActivity::class.java))
        }

        btnAddClass.setOnClickListener {
            startActivity(Intent(this, AddClassOrJoinActivity::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }
    }

    private fun setupSearch(
        etSearch: EditText,
        imgSearch: ImageView,
        imgFilter: ImageView
    ) {
        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class name", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            }
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupClassClicks(
        imgFilipinoCard: ImageView,
        imgMathCard: ImageView,
        imgPeCard: ImageView,
        imgEnglishCard: ImageView,
        tvFilipino: TextView,
        tvMath: TextView,
        tvPe: TextView,
        tvEnglish: TextView,
        classCard1: LinearLayout,
        classCard2: LinearLayout
    ) {
        imgFilipinoCard.setOnClickListener { openSubjectDetails("Filipino") }
        imgMathCard.setOnClickListener { openSubjectDetails("Mathematics") }
        imgPeCard.setOnClickListener { openSubjectDetails("Physical Education") }
        imgEnglishCard.setOnClickListener { openSubjectDetails("English") }

        tvFilipino.setOnClickListener { openSubjectDetails("Filipino") }
        tvMath.setOnClickListener { openSubjectDetails("Mathematics") }
        tvPe.setOnClickListener { openSubjectDetails("Physical Education") }
        tvEnglish.setOnClickListener { openSubjectDetails("English") }

        classCard1.setOnClickListener {
            val intent = Intent(this, ClassDetailsActivity::class.java)
            intent.putExtra("class_name", "Introduction to Computing")
            startActivity(intent)
        }

        classCard2.setOnClickListener {
            val intent = Intent(this, ClassDetailsActivity::class.java)
            intent.putExtra("class_name", "Data Structures")
            startActivity(intent)
        }
    }

    private fun openSubjectDetails(subjectName: String) {
        val intent = Intent(this, ClassDetailsActivity::class.java)
        intent.putExtra("subject_name", subjectName)
        startActivity(intent)
    }

    private fun setupBottomNavigation() {
        findViewById<LinearLayout>(R.id.navHome).setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navClasses).setOnClickListener {
            // Already in MyClassesActivity
        }

        findViewById<LinearLayout>(R.id.navNotification).setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navProfile).setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navMore).setOnClickListener {
            startActivity(Intent(this, MoreActivity::class.java))
            finish()
        }
    }
}