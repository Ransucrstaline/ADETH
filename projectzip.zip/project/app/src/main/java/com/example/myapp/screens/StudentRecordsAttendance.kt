package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class StudentRecordsAttendance : AppCompatActivity() {

    private lateinit var etSearch: EditText
    private lateinit var tableBody: LinearLayout

    private val attendanceMap = mapOf(
        "Hannah Isabelle" to listOf(
            AttendanceInfo("Present - 28", 30, listOf("April 10, 2026", "April 12, 2026")),
            AttendanceInfo("Late - 2", 30, listOf("April 11, 2026")),
            AttendanceInfo("Absent - 1", 30, listOf("April 20, 2026"))
        ),
        "John Cruz" to listOf(
            AttendanceInfo("Present - 25", 27, listOf("April 10, 2026")),
            AttendanceInfo("Absent - 2", 27, listOf("April 14, 2026"))
        )
    )

    private var currentStudentName: String = ""
    private var currentStudentSection: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_student_records_attendance)

        // ===== HEADER BUTTONS =====
        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnFilter = findViewById<ImageView>(R.id.btnFilter)
        val btnCalendar = findViewById<ImageView>(R.id.btnCalendar)

        // ===== INPUTS =====
        etSearch = findViewById(R.id.etSearch)
        tableBody = findViewById(R.id.tableBody)

        // ===== GET DATA FROM PREVIOUS SCREEN =====
        currentStudentName = intent.getStringExtra("student_name") ?: ""
        currentStudentSection = intent.getStringExtra("student_section") ?: ""

        // ===== BUTTON ACTIONS =====
        btnAdd.setOnClickListener {
            Toast.makeText(this, "Add clicked", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            Toast.makeText(this, "Menu clicked", Toast.LENGTH_SHORT).show()
        }

        btnFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnCalendar.setOnClickListener {
            Toast.makeText(this, "Calendar clicked", Toast.LENGTH_SHORT).show()
        }

        // ===== LOAD DATA =====
        val list = attendanceMap[currentStudentName] ?: emptyList()
        renderAttendanceRows(list)

        // ===== SEARCH =====
        etSearch.setOnEditorActionListener { _, _, _ ->
            val query = etSearch.text.toString().trim().lowercase()
            val filtered = list.filter {
                it.attendanceLabel.lowercase().contains(query)
            }
            renderAttendanceRows(filtered)

            Toast.makeText(this, "Searching: $query", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun renderAttendanceRows(list: List<AttendanceInfo>) {
        tableBody.removeAllViews()

        if (list.isEmpty()) {
            val emptyText = TextView(this).apply {
                text = "No attendance records found"
                textSize = 15f
                setPadding(32, 32, 32, 32)
            }
            tableBody.addView(emptyText)
            return
        }

        list.forEachIndexed { index, item ->

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(24, 24, 24, 24)
            }

            val sectionText = TextView(this).apply {
                text = currentStudentSection
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            val attendanceText = TextView(this).apply {
                text = item.attendanceLabel
                textSize = 14f
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            row.addView(sectionText)
            row.addView(attendanceText)

            // 👉 CLICK → GO TO DATE SCREEN
            row.setOnClickListener {
                val intent = Intent(this, StudentRecordsDate::class.java)
                intent.putExtra("student_name", currentStudentName)
                intent.putExtra("student_section", currentStudentSection)
                intent.putExtra("attendance_label", item.attendanceLabel)
                intent.putExtra("total_students", item.totalStudents)
                intent.putStringArrayListExtra("date_list", ArrayList(item.dateList))
                startActivity(intent)
            }

            tableBody.addView(row)

            // divider
            if (index != list.lastIndex) {
                val divider = android.view.View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        1
                    )
                    setBackgroundColor(android.graphics.Color.parseColor("#D9D9D9"))
                }
                tableBody.addView(divider)
            }
        }
    }
}