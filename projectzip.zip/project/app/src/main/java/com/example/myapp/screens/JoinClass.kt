package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class JoinClass : AppCompatActivity() {

    private lateinit var btnAdd: ImageView
    private lateinit var btnMenu: ImageView
    private lateinit var imgSearch: ImageView
    private lateinit var imgFilter: ImageView
    private lateinit var btnBack: ImageView

    private lateinit var etSearch: EditText
    private lateinit var etClassCode: EditText

    private lateinit var btnJoin: Button

    private lateinit var navHome: LinearLayout
    private lateinit var navClasses: LinearLayout
    private lateinit var navNotification: LinearLayout
    private lateinit var navProfile: LinearLayout
    private lateinit var navMore: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_join_class)

        initViews()
        setupClicks()
    }

    private fun initViews() {
        btnAdd = findViewById(R.id.btnAdd)
        btnMenu = findViewById(R.id.btnMenu)
        imgSearch = findViewById(R.id.imgSearch)
        imgFilter = findViewById(R.id.imgFilter)
        btnBack = findViewById(R.id.btnBack)

        etSearch = findViewById(R.id.etSearch)

        btnJoin = findViewById(R.id.btnJoin)

        navHome = findViewById(R.id.navHome)
        navClasses = findViewById(R.id.navClasses)
        navNotification = findViewById(R.id.navNotification)
        navProfile = findViewById(R.id.navProfile)
        navMore = findViewById(R.id.navMore)
    }

    private fun setupClicks() {
        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class to search", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching for: $query", Toast.LENGTH_SHORT).show()
            }
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnBack.setOnClickListener {
            finish()
        }

        btnJoin.setOnClickListener {
            val classCode = etClassCode.text.toString().trim()

            if (classCode.isEmpty()) {
                Toast.makeText(this, "Enter class code", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Joined class successfully", Toast.LENGTH_SHORT).show()
                finish()
            }
        }

        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navClasses.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
            finish()
        }

        navMore.setOnClickListener {
            startActivity(Intent(this, MoreActivity::class.java))
            finish()
        }
    }
}