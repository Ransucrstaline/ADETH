package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class ChangePassword : AppCompatActivity() {

    private var currentVisible = false
    private var newVisible = false
    private var confirmVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        val btnMenu = findViewById<ImageView>(R.id.btnMenu)
        val btnBack = findViewById<ImageView>(R.id.btnBack)

        val etCurrentPassword = findViewById<EditText>(R.id.etCurrentPassword)
        val etNewPassword = findViewById<EditText>(R.id.etNewPassword)
        val etConfirmPassword = findViewById<EditText>(R.id.etConfirmPassword)

        val btnToggleCurrent = findViewById<ImageView>(R.id.btnToggleCurrent)
        val btnToggleNew = findViewById<ImageView>(R.id.btnToggleNew)
        val btnToggleConfirm = findViewById<ImageView>(R.id.btnToggleConfirm)

        val btnCancel = findViewById<Button>(R.id.btnCancel)
        val btnSavePassword = findViewById<Button>(R.id.btnApplyChanges)

        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        btnBack.setOnClickListener {
            finish()
        }

        btnToggleCurrent.setOnClickListener {
            currentVisible = !currentVisible
            togglePassword(etCurrentPassword, currentVisible)
        }

        btnToggleNew.setOnClickListener {
            newVisible = !newVisible
            togglePassword(etNewPassword, newVisible)
        }

        btnToggleConfirm.setOnClickListener {
            confirmVisible = !confirmVisible
            togglePassword(etConfirmPassword, confirmVisible)
        }

        btnCancel.setOnClickListener {
            finish()
        }

        btnSavePassword.setOnClickListener {
            val currentPassword = etCurrentPassword.text.toString().trim()
            val newPassword = etNewPassword.text.toString().trim()
            val confirmPassword = etConfirmPassword.text.toString().trim()

            if (currentPassword.isEmpty() || newPassword.isEmpty() || confirmPassword.isEmpty()) {
                Toast.makeText(this, "Please complete all fields", Toast.LENGTH_SHORT).show()
            } else if (newPassword != confirmPassword) {
                Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Password changed successfully", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }

    private fun togglePassword(editText: EditText, visible: Boolean) {
        if (visible) {
            editText.inputType =
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        } else {
            editText.inputType =
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        editText.setSelection(editText.text.length)
    }
}