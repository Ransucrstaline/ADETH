package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class Add : AppCompatActivity() {

    private lateinit var imgLogo: ImageView
    private lateinit var btnAdd: ImageView
    private lateinit var btnMenu: ImageView

    private lateinit var etSearch: EditText
    private lateinit var imgSearch: ImageView
    private lateinit var imgFilter: ImageView

    private lateinit var btnCreateClass: LinearLayout
    private lateinit var btnJoinClass: LinearLayout
    private lateinit var btnUploadMaterial: LinearLayout
    private lateinit var btnCreateQuiz: LinearLayout
    private lateinit var btnCreateExam: LinearLayout
    private lateinit var btnAddAnnouncement: LinearLayout
    private lateinit var btnBack: ImageView

    private lateinit var navHome: LinearLayout
    private lateinit var navClasses: LinearLayout
    private lateinit var navNotification: LinearLayout
    private lateinit var navProfile: LinearLayout
    private lateinit var navMore: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_options)

        initViews()
        setupClicks()
    }

    private fun initViews() {
        imgLogo = findViewById(R.id.imgLogo)
        btnAdd = findViewById(R.id.btnAdd)
        btnMenu = findViewById(R.id.btnMenu)

        etSearch = findViewById(R.id.etSearch)
        imgSearch = findViewById(R.id.imgSearch)
        imgFilter = findViewById(R.id.imgFilter)

        btnCreateClass = findViewById(R.id.btnCreateClass)
        btnJoinClass = findViewById(R.id.btnJoinClass)
        btnUploadMaterial = findViewById(R.id.btnUploadMaterial)
        btnCreateQuiz = findViewById(R.id.btnCreateQuiz)
        btnCreateExam = findViewById(R.id.btnCreateQuiz)
        btnAddAnnouncement = findViewById(R.id.btnAddAnnouncement)
        btnBack = findViewById(R.id.btnBack)

        navHome = findViewById(R.id.navHome)
        navClasses = findViewById(R.id.navClasses)
        navNotification = findViewById(R.id.navNotification)
        navProfile = findViewById(R.id.navProfile)
        navMore = findViewById(R.id.navMore)
    }

    private fun setupClicks() {
        btnAdd.setOnClickListener {
            Toast.makeText(this, "You are already on Add screen", Toast.LENGTH_SHORT).show()
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        imgSearch.setOnClickListener {
            val query = etSearch.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "Please enter a class to search", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Searching for: $query", Toast.LENGTH_SHORT).show()
            }
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnBack.setOnClickListener {
            finish()
        }

        btnCreateClass.setOnClickListener {
            startActivity(Intent(this, CreateClassActivity::class.java))
        }

        btnJoinClass.setOnClickListener {
            startActivity(Intent(this, JoinClass::class.java))
        }

        btnUploadMaterial.setOnClickListener {
            startActivity(Intent(this, UploadMaterialActivity::class.java))
        }

        btnCreateQuiz.setOnClickListener {
            startActivity(Intent(this, CreateQuiz::class.java))
        }

        btnAddAnnouncement.setOnClickListener {
            startActivity(Intent(this, AnnouncementActivity::class.java))
        }

        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navClasses.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
            finish()
        }

        navMore.setOnClickListener {
            startActivity(Intent(this, MoreActivity::class.java))
            finish()
        }
    }
}