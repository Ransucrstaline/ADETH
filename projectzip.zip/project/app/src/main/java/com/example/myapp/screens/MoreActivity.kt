package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class MoreActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_more)

        val btnAdd = findViewById<ImageButton>(R.id.btnAdd)
        val btnMenu = findViewById<ImageButton>(R.id.btnMenu)
        val imgFilter = findViewById<ImageView>(R.id.imgFilter)
        val btnCloseOuter = findViewById<ImageView>(R.id.btnCloseOuter)
        val btnCloseInner = findViewById<ImageView>(R.id.btnCloseInner)

        val cbShuffleQuestions = findViewById<CheckBox>(R.id.cbShuffleQuestions)
        val cbShuffleAnswers = findViewById<CheckBox>(R.id.cbShuffleAnswers)
        val spinnerPoints = findViewById<Spinner>(R.id.spinnerPoints)
        val spinnerAttempts = findViewById<Spinner>(R.id.spinnerAttempts)
        val etTimer = findViewById<EditText>(R.id.etTimer)
        val btnApply = findViewById<Button>(R.id.btnApply)

        // ✅ YOUR NEW HELP CENTER BUTTON

        val numbers = arrayOf("1", "2", "3", "4", "5", "10")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, numbers)
        spinnerPoints.adapter = adapter
        spinnerAttempts.adapter = adapter

        btnAdd.setOnClickListener {
            startActivity(Intent(this, Add::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        btnCloseOuter.setOnClickListener {
            finish()
        }

        btnCloseInner.setOnClickListener {
            Toast.makeText(this, "Inner panel closed", Toast.LENGTH_SHORT).show()
        }

        // ✅ APPLIED YOUR CODE HERE


        btnApply.setOnClickListener {
            val points = spinnerPoints.selectedItem.toString()
            val attempts = spinnerAttempts.selectedItem.toString()
            val timer = etTimer.text.toString().trim()

            val message = """
                Shuffle Questions: ${cbShuffleQuestions.isChecked}
                Shuffle Answers: ${cbShuffleAnswers.isChecked}
                Points: $points
                Attempts: $attempts
                Timer: ${timer.ifEmpty { "00:00:00" }}
            """.trimIndent()

            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }

        setupBottomNavigation()
    }

    private fun setupBottomNavigation() {

        findViewById<LinearLayout>(R.id.navHome).setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navClasses).setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navNotification).setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navProfile).setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navMore).setOnClickListener {
            // already here
        }
    }
}