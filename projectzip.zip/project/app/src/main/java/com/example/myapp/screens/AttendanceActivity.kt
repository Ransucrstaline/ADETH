package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class AttendanceActivity : AppCompatActivity() {

    private var selectedStatus = "Present"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_attendance)

        val btnAdd = findViewById<ImageButton>(R.id.btnAdd)
        val btnMenu = findViewById<ImageButton>(R.id.btnMenu)
        findViewById<EditText>(R.id.etSearch)
        val imgFilter = findViewById<ImageView>(R.id.imgFilter)

        val btnBack = findViewById<ImageView>(R.id.btnBack)
        val btnEditDate = findViewById<ImageView>(R.id.btnEditDate)
        val btnPrevMonth = findViewById<TextView>(R.id.btnPrevMonth)
        val btnNextMonth = findViewById<TextView>(R.id.btnNextMonth)
        val btnClear = findViewById<TextView>(R.id.btnClear)
        val btnCancelDate = findViewById<TextView>(R.id.btnCancelDate)
        val btnOkDate = findViewById<TextView>(R.id.btnOkDate)

        val optionPresent = findViewById<LinearLayout>(R.id.optionPresent)
        val optionAbsent = findViewById<LinearLayout>(R.id.optionAbsent)

        val btnSubmit = findViewById<Button>(R.id.btnSubmit)
        val tvSelectedDate = findViewById<TextView>(R.id.tvSelectedDate)

        // ===== BOTTOM NAV =====
        val navHome = findViewById<LinearLayout>(R.id.navHome)
        val navClasses = findViewById<LinearLayout>(R.id.navClasses)
        val navNotification = findViewById<LinearLayout>(R.id.navNotification)
        val navProfile = findViewById<LinearLayout>(R.id.navProfile)
        val navMore = findViewById<LinearLayout>(R.id.navMore)

        btnAdd.setOnClickListener {
            startActivity(Intent(this, AddClassOrJoinActivity::class.java))
        }

        btnMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        imgFilter.setOnClickListener {
            Toast.makeText(this, "Filter clicked", Toast.LENGTH_SHORT).show()
        }

        // applied from your Attendance code
        btnBack.setOnClickListener {
            finish()
        }

        btnEditDate.setOnClickListener {
            Toast.makeText(this, "Edit date clicked", Toast.LENGTH_SHORT).show()
        }

        btnPrevMonth.setOnClickListener {
            Toast.makeText(this, "Previous month", Toast.LENGTH_SHORT).show()
        }

        btnNextMonth.setOnClickListener {
            Toast.makeText(this, "Next month", Toast.LENGTH_SHORT).show()
        }

        btnClear.setOnClickListener {
            tvSelectedDate.text = "No date selected"
            Toast.makeText(this, "Date cleared", Toast.LENGTH_SHORT).show()
        }

        btnCancelDate.setOnClickListener {
            Toast.makeText(this, "Selection cancelled", Toast.LENGTH_SHORT).show()
        }

        btnOkDate.setOnClickListener {
            Toast.makeText(this, "Date confirmed", Toast.LENGTH_SHORT).show()
        }

        optionPresent.setOnClickListener {
            selectedStatus = "Present"
            Toast.makeText(this, "Present selected", Toast.LENGTH_SHORT).show()
        }

        optionAbsent.setOnClickListener {
            selectedStatus = "Absent"
            Toast.makeText(this, "Absent selected", Toast.LENGTH_SHORT).show()
        }

        btnSubmit.setOnClickListener {
            Toast.makeText(
                this,
                "Attendance submitted\nDate: ${tvSelectedDate.text}\nStatus: $selectedStatus",
                Toast.LENGTH_LONG
            ).show()
        }

        // ===== BOTTOM NAV CLICK LISTENERS =====
        navHome.setOnClickListener {
            startActivity(Intent(this, HomeActivity::class.java))
            finish()
        }

        navClasses.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        navNotification.setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }

        navProfile.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
            finish()
        }

        navMore.setOnClickListener {
            startActivity(Intent(this, MoreActivity::class.java))
            finish()
        }
    }
}