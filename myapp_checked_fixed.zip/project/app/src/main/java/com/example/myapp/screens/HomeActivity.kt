package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R

class HomeActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val imgSearch = findViewById<ImageView>(R.id.imgSearch)
        val imgMenu = findViewById<ImageView>(R.id.imgMenu)

        val imgFilipino = findViewById<ImageView>(R.id.imgFilipino)
        val imgMath = findViewById<ImageView>(R.id.imgMath)
        val imgPe = findViewById<ImageView>(R.id.imgPe)
        val imgEnglish = findViewById<ImageView>(R.id.imgEnglish)

        val tvViewAll = findViewById<TextView>(R.id.tvViewAll)

        // SEARCH
        imgSearch.setOnClickListener {
            Toast.makeText(this, "Search clicked", Toast.LENGTH_SHORT).show()
        }

        // MENU → PROFILE
        imgMenu.setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
        }

        // SUBJECT CLICKS
        imgFilipino.setOnClickListener { openSubject("Filipino") }
        imgMath.setOnClickListener { openSubject("Mathematics") }
        imgPe.setOnClickListener { openSubject("Physical Education") }
        imgEnglish.setOnClickListener { openSubject("English") }

        // VIEW ALL
        tvViewAll.setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
        }

        // BOTTOM NAVIGATION
        setupBottomNavigation()
    }

    private fun openSubject(subject: String) {
        val intent = Intent(this, MyClassesActivity::class.java)
        intent.putExtra("subject_name", subject)
        startActivity(intent)
    }

    private fun setupBottomNavigation() {
        findViewById<LinearLayout>(R.id.navHome).setOnClickListener {
            // already in HomeActivity, no action
        }

        findViewById<LinearLayout>(R.id.navClasses).setOnClickListener {
            startActivity(Intent(this, MyClassesActivity::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navNotification).setOnClickListener {
            startActivity(Intent(this, Notification::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navProfile).setOnClickListener {
            startActivity(Intent(this, Profile::class.java))
            finish()
        }

        findViewById<LinearLayout>(R.id.navMore).setOnClickListener {
            startActivity(Intent(this, MoreActivity::class.java))
            finish()
        }
    }
}