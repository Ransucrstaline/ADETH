package com.example.myapp.screens

import android.content.Intent
import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.example.studyworks.R   // ✅ FIXED: make sure this matches your app package

class GetStarted : AppCompatActivity() {

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_get_started)

		val btnGetStarted = findViewById<LinearLayout>(R.id.btnGetStarted)

		btnGetStarted.setOnClickListener {
			startActivity(Intent(this, Login::class.java))
			finish() // optional: prevents going back to GetStarted
		}
	}
}